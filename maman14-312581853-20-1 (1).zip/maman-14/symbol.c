#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "textActions.h"
#include "symbol.h"


int setSymblNext(PSmbl* head, char *cmd, int source, int length, int addresSymbol, short type)
{
	PSmbl pt;	
	if(*head)
	{		
		pt = *head;		
		while(pt->next)
		{			
			pt = pt->next;
		}		
		pt->next = (PSmbl)malloc(sizeof(symList));		
		pt = pt->next;
	}
	else
	{		
		*head = (PSmbl)malloc(sizeof(symList));
		pt = *head;
	}	
	if(pt && (pt->name = (char *)malloc((length+1)*sizeof(char))))
	{			
		pt->next = NULL;
		pt->name = strncpy(pt->name, cmd+source,length);
		pt->name[length] = '\0';
		pt->addresSymbol = addresSymbol;
		pt->type = type;
	}
	else
	{		
		return -2;
	}
	return 1;
}

int symExist(PSmbl head, char *name)
{	
	while(head)
	{
		if(strcmp(head->name,name) == 0)
			return 1;
		head = head->next;		
	}
	return 0;
}

PSmbl isSymblExist(PSmbl head, char *name)
{
	while(head)
	{
		if(strcmp(head->name,name) == 0)
			return head;
		head = head->next;		
	}
	return NULL;
}

int isEmpty(PSmbl head)
{
	return (head)? 0 : 1;
}

PSmbl headList(PSmbl* head)
{
	PSmbl p;
	if(!isEmpty(*head))
	{
		p = *head;
		*head = (*head)->next;
		return p;
	}
	return NULL;
}

void deleteAll(PSmbl* head)
{
	PSmbl pt,next;
	if(!isEmpty(*head))
	{
		pt = *head;
		while(pt)
		{
			next = pt->next;
			free(pt->name);
			free(pt);
			pt = next;
		}
		*head = NULL;
	}
}

int addNextSymbols(PSmbl* head, char *cmd, int source)
{
	int start,end,count=0;	
	while(textEnd(source,cmd) && source>=0)
	{
		start = jumpSpace(cmd, source);
		end = strEnd(cmd, start);
		if(end>-1)
		{						
			if(setSymblNext(head, cmd, start, end - start , 0, 2) <0 )
				return -2;
			count++;
			source = jumpComma(cmd,end);				
			if((source == -1 && textEnd(end, cmd)) || (source != -1 && !textEnd(source,cmd)))
				return -3;			
		}
		else
		{
			return -1;
		}
	}
	return count;
}

void updateSymbolTyp(PSmbl head, int IC)
{
	while(head)
	{
		if(head->type <= 1)
			head->addresSymbol += IC;
		head = head->next;
	}
}
