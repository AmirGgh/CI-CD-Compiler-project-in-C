typedef struct macroList {
    char macroName[15];
    char *codeM;
    int numLines;
    struct macroList *next;
} mcList;

void pushMacro(mcList *ml, char *name, FILE *f);
void destroyMacroList(mcList* ml);
mcList *search(mcList* ml, char *mcName);
int validMacroName(char *nameMacro);
int preAsm(const char *fileName);

