#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "textActions.h"
#define SymbolMax 30
char buff[81];
static int index = -1;
char *directives[5] = {"data\0","string\0","struct\0","entry\0","extern\0"};
char *orders[16] = {"mov\0","cmp\0","add\0","sub\0","not\0","clr\0","lea\0","inc\0","dec\0","jmp\0","bne\0","red\0","prn\0","jsr\0","rts\0","hlt\0"};

char *getCmd(FILE *fp1)/*Input: pointer to file. Output: char[81] that in the end of comman: /0*/
{
	char c;
	char *arr;
	int i;
	if((c=getNext(fp1))!= EOF)
		buff[++index] = c;
	else
		return NULL;
	arr = (char *)malloc(lineSize*sizeof(char));
	if(arr)
	{
		i = 0;
		while((c = getNext(fp1)) != EOF && c != '\n' && i<(lineSize-1))
		{
			arr[i] = c;
			i++;
		}
		arr[i] = '\0';
		if(i <= (lineSize-1) && c!= EOF && c != '\n')
		{
			buff[++index] = c;
			while((c = getNext(fp1)) != EOF && c != '\n');
			if(c == EOF)			
				buff[++index] = c;			
			return "`Syntax error, too much long command.\0";
		}
		else
			return arr;

	}
	else
	{
		return "`Dynamic allocatio error, can not create space.\0";
	}	
}

char getNext(FILE *fp1)/*Input: pointer to file. Output: next char. Discounts: file is open for reading*/
{
	if(index>-1)
	{
		return buff[index--];
	}
	return getc(fp1);
}


int jumpSpace(char *cmd, int source)/*Input: pointer to arry, and starting point. Output: point after starting text. Discounts: (1)*/
{
	char c;
	while((c = cmd[(source)]) != '\0' && isspace(c))
		source++;
	return source;
}

int jumpComma(char *cmd, int source)/*Input: pointer to arry, and starting poin. Output: point after comma, or -1 if not found Discounts: (1)*/
{
	source = jumpSpace(cmd,source);
	if(cmd[source] == ',')
	{
		source++;
		return source;
	}
	else
	{
		return -1;
	}
}

int textEnd(int source, char *cmd)/*Input: pointer to arry, and starting poin. Output: if there is text left? 1 : 0. Discounts: (1)*/
{
	source = jumpSpace(cmd,source);
	return (cmd[source] != '\0')? 1 : 0;	
}

int strEnd(char *cmd, int source)/*Input: pointer to arry, and starting poin. Output: point of end of text (comma, apostrophes or space). Discounts: (1)*/
{
	char c;
	while((c = cmd[(source)]) != '\0' && !isspace(c) && (c != ','))
		source++;
	return source;
}

int symbolPlace(char *cmd, int source){
    int iter=1;
    if (isalpha(cmd[source])){
        while(isalpha(cmd[source+iter]) || isdigit(cmd[source+iter])){
            if(iter>SymbolMax){
                return -1;
            }
            iter++;
        }
        if (cmd[source+iter] == ':')
            return source+iter;
    }
    return -1;
}
int directivePlace(char *cmd, int source){
    int iter = 1;
    char directive[7];
    int i;    
    if(cmd[source] == '.'){        
        while((cmd[source+iter] != ' ') && (cmd[source+iter] !='\t') && (cmd[source+iter] !='\0')){
            if(iter>=7)
                return -1;
            directive[iter-1]=cmd[source+iter];
            iter++;
        }        
        directive[iter-1]='\0';
        for (i=0;i<5;i++){
            if(strcmp(directive,directives[i])==0){
                return i+1;
            }
        }
        return -1;

    }    
    return -1;
}
int isCmd(char *cmd, int source){
    int iter=0;
    char order[5];
    int i;    
    while (iter<4 && cmd[source+iter] !='\0' && !isspace(cmd[source+iter])){
        order[iter]=cmd[source+iter];
        iter++;
    }    
    order[iter]='\0';
    for (i=0;i<16;i++){
        if(strcmp(order,orders[i])==0){
            return i;
        }
    }    
    return -1;
}

int numLocation(char *cmd, int source)
{
    int start = source ,end = 0;
    if(start+end < lineSize && (cmd[start+end] == '-' || cmd[start+end] == '+'))
        start++;
    while (cmd[start+end] != '\0' && cmd[start+end]>='0' && cmd[start+end]<='9'){        
        end++;
    }
    return (end == 0)? -1: start+end;
}
