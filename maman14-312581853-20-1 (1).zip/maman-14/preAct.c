#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "textActions.h"
#include "symbol.h"
#include "texTo.h"
#include "preAct.h"
#define SymbolMax 30

char * countAct (int actionNum, int *L, char *cmd, int source)
{
	int NumberofLine = 1, addr1,addr2; /*1 for first word command*/
	source+=3;
	if(actionNum>=14)	
	{
		if(actionNum == 15)
			source+=2;
		if(!textEnd(source,cmd))
			return "`Syntax error, unexpected text after action name.\0";
	}
	else/*needed at least one operste*/
	{
		if(!textEnd(source,cmd))
			return "`Syntax error, expected operate after action name.\0";
		source = jumpSpace(cmd,source);
		addr1 = getMetdAdrs(cmd,source);
		switch (addr1)
		{
			case 0:
			if(actionNum<=3 || actionNum == 12)
				NumberofLine += 1;
			else
				return "`Syntax error, Addressing number: 0, can't be in first addressing at this action.\0";
			break;
			case 1:
			NumberofLine += 1;
			break;
			case 2:
			NumberofLine += 2;
			break;
			case 3:
			if(actionNum != 6)
				NumberofLine += 1;
			else
				return "`Syntax error, Addressing number: 3, can't be in first addressing at this action.\0";
			break;
		}
		source = strEnd(cmd,source);
		if(actionNum <= 3 || actionNum == 6)
		{
			source = jumpComma(cmd,source);
			if(source == -1)
				return "`Syntax error, expected a break ',' and another command in this action.\0";
			source = jumpSpace(cmd,source);
			addr2 = getMetdAdrs(cmd,source);
			switch (addr2)
			{
				case 0:
				if(actionNum == 1)
					NumberofLine += 1;
				else
					return "`Syntax error, Addressing number: 0, can't be in second addressing at this action.\0";
				break;
				case 1:
				NumberofLine += 1;
				break;
				case 2:
				NumberofLine += 2;
				break;
				case 3:				
					NumberofLine += (addr1 == 3)? 0 : 1;				
				break;
			}
		}
		else{
			if(textEnd(source,cmd))
				return "`Syntax error, unexpected text, after operate.\0";
		}
	}
	*L = NumberofLine;
	return NULL;
}


int getMetdAdrs(char *cmd, int source)/*Discont: there is text left. Output: number of */
{	
	int i=0;
	if(cmd[source] == '#')
		return 0;
	if(cmd[source] == 'r' && cmd[source+1] >= '0' && cmd[source+1] <= '7')
		return 3;
	while(cmd[source+i] != '\0' && !isspace(cmd[source+i]) && cmd[source+i] != '.' && cmd[source+i] != ',')
		i++;
	return (cmd[source+i] == '.')? 2:1;
}

char *adressOfSymbol(char *cmd, int source, int end, PSmbl head)
{
	int Nlength = end - source +1,i;
	char *bin=NULL;
	static char name[SymbolMax];
	PSmbl temp = head;
	for(i=0;i<Nlength;i++)
	{
		name[i] = cmd[source+i];
	}
	name[i] = '\0';
	while(temp)
	{
		if(strcmp(temp->name,name) == 0)
		{
			bin = decToBin(temp->addresSymbol);
			if(bin[0] == '%')
				return "`Dynamic allocatio error.\0";
			for(i=0;i<8;i++)
				bin[i] = bin[i+2];
			if(temp->type == 2)
			{
				bin[9] = '1';
				bin[8] = '0';
			}else
			{
				bin[9] = '0';
				bin[8] = '1';
			}
			bin[7] = '|';
			return bin;
		}
		temp = temp->next;
	}
	return "`Symbol was tipe, that is not define.\0";
}
