typedef struct LablObjList * pLblList; /*Pointer to node*/
typedef struct LablObjList
{
	short lbl;/*0 or 1*/
	char *name;/*name of symbol*/
	char *address;/*address of symbol in AsmMMN*/
	pLblList next; /*Pointer to next*/
}LablObjList;

int addLbl(pLblList * head ,char *name , int addresSymbol,short lbl); /*Input: pointer to head of LablObjList, and all data needed for new node. Output: 1 if succses to enter it, or number<0 otherwise*/
int emptyLbl(pLblList head);/*Input: pointer to head of LablObjList, Output: 1 if empty, or number<0 otherwise*/
pLblList getNextEAE(pLblList after); /*Input: pointer to LablObjList, Output: pointer to next node*/
char * getLablObjList (pLblList *head);/*Input: pointer to head of LablObjList, Output: head of list as a string to print to file, and delete head of file.*/
void deleteLbl (pLblList *head);/*Input: pointer to head of LablObjList. Delete all list, no output*/
void printListEAE(pLblList head);/*Input: pointer to head of LablObjList. Ouyput: print list to screen*/
