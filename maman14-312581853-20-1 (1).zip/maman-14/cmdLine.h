#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include "textActions.h"
#include "texTo.h"
#ifndef directiveSize
#define directiveSize
#define stringSize 7
#define structSize 7
#define dataSize 5
#define externSize 7
#define entrySize 7
#endif


typedef struct lineList * listP;
typedef struct lineList{
    int list; /* in decimal */
    int DC; /*in decimal*/
    listP next;

} lineList;

/*(1) returns 1 if all worked well, -2 if there was a dynamic allocation error and -1 otherwise*/



int addNode(listP *head , int number, int * DC);  /*Input: a pointer to a pointer to a lineList structure, a number which is the list and a pointer to DC
                                                         *Output: (1) above
                                                         *Action: First, it creates a new lineList structure which contains the inputted number and DC, then if there is a linked list which the inputted lineList structure as its head, it adds it to the end of the list, otherwise the function sets it to be the head of the list. The function also adds 1 to the given DC*/

int addStr(char *cmd, int source, int *DC, listP *head);     /*Input: a string which contains a string (with quotations), an integer that represents the starting point, a pointer to DC, and a pointer to the head of the list
                                                                         *Output: If the string was successfully added to the lineList, the function returns the position after the second quotations, else -2 if there was a dynamic allocation error and -1 otherwise
                                                                         * Action: The functions adds every letter to the lineList structure, including the '\0' character*/

int addStruct(char *cmd, int source, int *DC, listP *head);     /*Input: a string which represents a struct directive, an integer source, a pointer to DC and a pointer to the head of the lineList
                                                                         *Output: if successful in adding the struct, it returns the index after all parameters. else, it returns -2 if there was a dynamic allocation error and -1 otherwise
                                                                         *Action: First it adds the number to the lineList, and then it adds each letter of the string to the lineList, including '\0'*/

int addList(char *cmd, int source, int *DC, listP *head);        /*Input: Input: a string which represents a list directive, an integer source, a pointer to DC and a pointer to the head of the lineList
                                                                         *Output: if all the numbers have been added successfully, than the function returns the index after all the numbers, else return -2 if there was a dynamic allocation error and -1 otherwise.
                                                                         * Action: adds all the numbers provided in the .data directive to the lineList*/

void deleteList(listP * head);                                  /*Input: a pointer to the head of the lineList
                                                                         *Output: none
                                                                         * Action: frees the lineList*/

void printlineList(listP head); /*prints the list*/

