typedef struct symList *PSmbl;
typedef struct symList{
  char *name;
  int addresSymbol;/*in decimal*/  
  short type;/*0,1,2 or 3*/ 
  PSmbl next; 
}symList;

int setSymblNext(PSmbl *head, char *cmd, int source, int length, int addresSymbol, short type);/*Input: all data needed for new symbol, and head of list. Action: add symbol to list. Discounts: all data is corect. Output: 1 if saccsess, or number<0 otherwise.*/
int symExist(PSmbl head, char *name);/*Input: head of list and name to check existient. Output: 1 if exist 0 else.*/
PSmbl isSymblExist(PSmbl head, char *name);/*Input: head of list and name to check existient. Output: pointer to node if exist, or NULL else.*/
int isEmpty(PSmbl head);/*Input: head of list. Output: 1 if empty, 0 else.*/
PSmbl headList(PSmbl* head);/*Input: head of List. Output: head of list add delete source list.*/
void deleteAll(PSmbl *head);/*Input: head of List. Output: delete all list*/
int addNextSymbols(PSmbl *head, char *cmd, int source);/*Input: head of list, command and where to start from. Output: adding all Symbol to extern*/
void updateSymbolTyp(PSmbl head, int IC);/*Input: head of list and IC. Output: updating all symbols adress.*/
