#include "convCode.h"

int emptyCode(PCode head){
    if(head==NULL)
        return 1;
    return -1;
}

int addCode(PCode * head ,int address ,char *bin) {
    PCode newCode = (PCode) malloc(sizeof(codeNode));
    PCode temp;
    if (newCode == NULL) {
        return -2;
    }
    newCode->address = address;
    newCode->bin = bin;    
    newCode->next = NULL;
    if (emptyCode(*head)>0) {

        *head = newCode;
        return 1;
    }

    temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newCode;
    return 1;


}

PCode getNextCode(PCode current){
    return current->next;
}

char * getCode(PCode * head){
    char * converted=(char *)malloc(6*sizeof(char));
    PCode temp=*head;
    char * charTemp;
    if(!converted)
        return NULL;
    (*head)=(*head)->next;
    memcpy(converted,decToAsmMMN((temp)->address),2);
    converted[2]='\t';
    charTemp = converted+3;
    memcpy(charTemp,binToAsmMMN((temp)->bin),2);
    converted[5]='\0';
    return converted;
}

void deleteCode(PCode * head){
    PCode pt,temp;
	temp = *head;
	while(temp)
	{
		pt = temp->next;		
        free(temp->bin);
		free(temp);
		temp = pt;
	}
	*head = NULL;
}
