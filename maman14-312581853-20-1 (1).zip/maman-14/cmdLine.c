#include "cmdLine.h"

int addNumber(char * command, int iter, int endNum, int *DC, listP * head);/*adds the number in cmd that is represented as a string from index 'iter' to index 'endNum'. returns (1) above.*/

int innerAddStr(char * cmd,int from,listP * head,int * DC); /*Receives as an input a char array command, which in its index from there is the beginning of a string ("), and adds it to the lineList.returns the position after the second quotation marks if succeeded,-2 if there was an error in dynamic allocation and -1 otherwise*/

int addNumber(char * cmd, int iter, int endNum, int *DC, listP * head){
    int newNumber = txtToInt(cmd,iter,endNum);        
    int added;
    if(newNumber>512 || newNumber<-512)
        return -1;
    if ((added = addNode(head, newNumber, DC) < 0))
        return added;
    return 1;
}

int addNode(listP *head , int number, int *DC){
    listP newData = (listP)malloc(sizeof(lineList));
    listP temp;
    if(newData == NULL){
        return -2;
    }
    newData->list=number;
    newData->DC=*DC;
    newData->next=NULL;
    *DC+=1;
    if(*head==NULL){
        *head=newData;
        return 1;
    }

    temp=*head;
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=newData;
    return 1;

}
int innerAddStr(char * cmd,int from,listP * head,int * DC){
    int iter=from;
    int added;
    if(cmd[iter]!='\"')
        return -1;
    iter++;
    while(cmd[iter]!='\"' && textEnd(iter, cmd)) {
        if ((added = addNode(head, cmd[iter], DC)) < 0)
            return added;
        iter++;
    }
    if(cmd[iter] != '\"')
        return -1;
    if((added = addNode(head,'\0',DC))<0)
        return added;
    return iter+1;
}
int addStr(char *cmd, int from, int *DC, listP *head){
    int iter=from+stringSize;    
    iter=jumpSpace(cmd,iter);
    return innerAddStr(cmd,iter,head,DC);
}

int addStruct(char *cmd, int from, int *DC, listP *head) {
    int iter = from+structSize;
    int endNum;
    int num;
    int endStruct;    
    iter = jumpSpace(cmd, iter);
    if ((endNum = numLocation(cmd, iter)) < 0) {
        return -1;
    }    
    num = addNumber(cmd,iter,endNum-1,DC,head);
    if(num<0)
        return num;
    iter=endNum;
    iter=jumpSpace(cmd,iter);
    if(cmd[iter]!=',')
        return -1;
    iter=jumpSpace(cmd,iter+1);
    if(cmd[iter]!='\"')
        return -1;
    if((endStruct=innerAddStr(cmd,iter,head,DC))<0)
        return endStruct;    
    return endStruct;
}

int addList(char *cmd, int from, int *DC, listP *head){
    int iter=from+dataSize;
    int endNum;
    int number;    
    iter=jumpSpace(cmd,iter);
    if(!textEnd(iter, cmd))
        return -1;
    if((endNum = numLocation(cmd,iter))<0)
        return endNum;    

    number=addNumber(cmd,iter,endNum-1,DC,head);
    if(number<0)
        return number;
    iter=endNum;    
    while(textEnd(iter, cmd)) {
        iter=jumpSpace(cmd,iter);
        if(cmd[iter]!=',')
            return iter;
        iter=jumpSpace(cmd,iter+1);
        if((endNum = numLocation(cmd,iter))<0)
            return endNum;        
        number=addNumber(cmd,iter,endNum-1,DC,head);
        if(number<0)
            return number;
        iter=endNum;        
    }
    return iter;
}

void deleteList(listP * head){    
    listP pt,temp;
    temp = *head;
    while(temp)
    {
        pt = temp->next;        
        free(temp);
        temp = pt;
    }
    *head = NULL;
}

void printlineList(listP head){
    listP temp = head;
    while(temp){
        printf("(%d,%d)\n",temp->list,temp->DC);
        temp=temp->next;
    }
}

