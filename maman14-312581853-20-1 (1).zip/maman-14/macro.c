#include <stdlib.h>
# include <stdio.h>
# include <string.h>
# include "macro.h"
# include "texTo.h"
# define MAX 81
const char start[] = "macro";
const char end[] = "endmacro";
const char s[] = " \n   ";

void pushMacro(mcList *ml, char *name, FILE *f) /**/
{

    mcList *currentML = ml;
    char line[MAX];
    while (currentML->next != NULL) 
    {
        currentML = currentML->next;
    }
    currentML->next = (mcList *) malloc(sizeof(mcList));/*new macro sruct*/
    ml->next->codeM = (char*)malloc(sizeof(char)*MAX);/*memmory for new macro code*/
    strcpy(currentML->next->macroName, name);/*save new macro name*/
    ml->numLines = 0;
    fgets(line, MAX, f);
    while(strstr(line,end) == NULL)/*copy macro code to struct*/
    {
    	ml->numLines++;
        strcat(currentML->next->codeM, line+1);
        fgets(line, MAX, f);
        ml->codeM = (char *) realloc(ml->codeM, ml->numLines*MAX);
    }
    currentML->next->next = NULL; /*next of new struct point to NULL */
}


void destroyMacroList(mcList* ml)
{
	mcList *current = NULL;
	while(ml)
	{
		free(ml->codeM);
		current = ml;
		ml = ml->next;
		free(current);
	}
}

mcList *search(mcList* ml, char *mcName)
{
	while(ml != NULL)
	{ 	         
		if(strstr(mcName, ml->macroName ) != NULL )/*if macro found*/
			return ml;
		ml=ml->next;
	}
	return NULL;
}

int validMacroName(char *nameMacro)
{
	int i = 0;
	char *ordersNDir[21] = {"data\0","string\0","struct\0","entry\0","extern\0","mov\0","cmp\0","add\0","sub\0","not\0","clr\0","lea\0","inc\0","dec\0","jmp\0","bne\0","red\0","prn\0","jsr\0","rts\0","hlt\0"};
	for(i=0; i<21; i++)
	{
        if(!strcmp(nameMacro, ordersNDir[i]))
        {
            return 0; /*name macro is prohibited*/
        }
	}
    return 1;
}

int preAsm(const char *fileName)
{
	FILE *fp, *preAsm ;
	char line[MAX], linetmp[MAX], *token, *orgFile = NULL, *preFile = NULL;
	mcList *ml = NULL, *pastMacro = NULL, *listBegin = NULL;
	orgFile = concatConst(fileName, ".as\0");
	fp = fopen(orgFile, "r+");
	preFile = concatConst(fileName, ".am\0");
	preAsm = fopen(preFile, "w+");

	if(fp)
	{
		while(!feof(fp))
		{    	  	
			fgets(line, sizeof(line), fp);

			if(ml != NULL) /*search if line contain macro name*/
			{   	 			
				strcpy(linetmp,line);
				if((pastMacro = search(ml,linetmp)) != NULL) /* if macro name found*/
				{
					fputs(pastMacro->codeM, preAsm); /*past a code in string to pre-file*/
					fgets(line, sizeof(line), fp); /*jump above macro name*/
				}
			}

			if(strstr(line, start) != NULL)
			{
				token = strtok(line, s); 
				token = strtok(NULL, s);
				if(validMacroName(token))
				{
					if(ml == NULL)
					{
						ml = (mcList *) malloc(sizeof(mcList));/*first new macro sruct*/
						listBegin = ml;
						ml->codeM = (char*)malloc(sizeof(char)*MAX);/*memmory for new macro code(only one line)*/
						ml->numLines=0;
						strcpy(ml->macroName, token);/*save new macro name*/
						fgets(line, MAX, fp);
						while(strstr(line,end) == NULL)/*copy macro code to struct*/
						{
							ml->numLines++;
							strcat(ml->codeM, line+1);
							fgets(line, MAX, fp);
							ml->codeM = (char *) realloc(ml->codeM, ml->numLines * MAX); /*realloc for next line*/
						}
						ml->next = NULL; /*next of new struct point to NULL */
					}
					else
					{
						pushMacro(ml, token, fp);
					}
					fgets(line, sizeof(line), fp); /*jump above endmacro*/ 
				}
				else
				{
					return 0; /*macro name is unvalid*/
				}
			}
			fputs(line, preAsm);
		}
		fclose(fp);
		fclose(preAsm);
	}
destroyMacroList(listBegin);

return 1;
}


