#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lable.h"
#include "texTo.h"

int addLbl(pLblList * head ,char *Nname , int Naddress,short NisExt)
{	
	pLblList pt, temp = (pLblList)malloc(sizeof(LablObjList));
	if(temp && (temp->address = decToAsmMMN(Naddress)))
	{
		temp->lbl = NisExt;
		temp->name = Nname;
		temp->next = NULL;
		if(*head)
		{
			pt = *head;
			while(pt->next)
				pt = pt->next;
			pt->next = temp;
		}
		else
		{
			*head = temp;
		}
	}
	else
	{
		return -2;
	}
	return 1;
}

int emptyLbl(pLblList head){ return (!head)? 1:0;}

pLblList getNextEAE(pLblList after){
	return after->next;
}

char * getLablObjList (pLblList *head)
{
	int length;
	pLblList pt;
	char *newString, *AsmMMN;
	if(*head)
	{
		pt = *head;
		length = strlen(pt->name) + 4;/* 1:sapce, 2-3: AsmMMN, 4: \0*/
		newString = (char *)malloc(length*sizeof(char));
		if(newString)
		{
			strcpy(newString,pt->name);
			strcat(newString, " ");
			AsmMMN = binToAsmMMN(pt->address);
			if(!AsmMMN)
				return "`Dynamic allocatio error.\0";
			strcat(newString, AsmMMN);
			newString[length-1]= '\0';
			return newString;
		}
		else
		{
			return "`Dynamic allocatio error.\0";
		}
		*head = pt->next;
	}
	else{
		return NULL;
	}
}

void deleteLbl (pLblList *head)
{
	pLblList pt,temp;
	temp = *head;
	while(temp)
	{
		pt = temp->next;
		free(temp->address);
		free(temp);
		temp = pt;
	}
	*head = NULL;
}

void printListEAE(pLblList head){
    pLblList temp = head;
    while(temp){
        printf("(%hi,%s,%s)\n", temp->lbl, temp->name, temp->address);
        temp=temp->next;
    }
}
