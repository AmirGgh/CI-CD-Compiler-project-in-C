int getMetdAdrs(char *cmd, int source);	
/*Input: command and index to start source.																			
																			* Output: adrressing number (0-3).																		
																			*/

char * countAct (int actionNum, int *L, char *cmd, int source); /*Input: action number, pointer to L, command and index to start.
																			* Discounts: (1) and, actionNumber is correct (0-15)
																			* Output: set L to number of nedded words in code file, and NULL if ther is NO ERROR
																			*/
char *adressOfSymbol(char *cmd, int source, int end, PSmbl head); /*Input: action number, pointer to L, command and index to start.
																			* Discounts: (1) and, actionNumber is correct
																			* Output: set L to number of nedded words in code file, and NULL if ther is NO ERROR
																			*/
