#ifndef lineSize
#define lineSize 81
#endif
char *getCmd(FILE *);/*Input: pointer to file. Output: char[81] that in the end of comman: /0. Discounts: file is open for reading*/
char getNext(FILE *);/*Input: pointer to file. Output: next char. Discounts: file is open for reading*/
int jumpSpace(char *cmd, int source);/*Input: pointer to arry, and starting poin. Output: point after starting text. Discounts: (1)*/
int jumpComma(char *cmd, int source);/*Input: pointer to arry, and starting poin. Output: point after comma. Discounts: (1)*/
int textEnd(int source, char *cmd);/*Input: pointer to arry, and starting poin. Output: if there is text left? 1 : 0. Discounts: (1)*/
int strEnd(char *cmd, int source);/*Input: pointer to arry, and starting poin. Output: point of end of text (comma, apostrophes or space). Discounts: (1)*/

int symbolPlace(char *cmd, int source);/* input: char array which represents a string, and an integer 'source'
                                       * output: an integer
                                       * action: if starting from the index 'source', there is a label (as described in the book) in the string, return the index of the end of the label, else return -1 */

int directivePlace(char *cmd, int source);/* input: char array which represents a string, and an integer 'source'
                                           * output: an integer
                                           * action: if starting from the index 'source', there is a directive (as described in the book) in the string, return the index of the directive by the bool, else return -1 */

int isCmd(char *cmd, int source);/* input: char array which represents a string, and an integer 'source'
                                           * output: an integer
                                           * action: if starting from the index 'source', there is an order (as described in the book) in the string, return the index of the order by the bool, else return -1 */

int numLocation(char *cmd, int source);/* input: char array which represents a string, and an integer 'source'
                                           * output: an integer, index after the number or -1 otherwise.
                                           * action: if starting from the index 'source', there is a number in the string, return the index of the end of the number, else return -1 */
