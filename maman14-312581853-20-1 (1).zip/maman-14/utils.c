#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "textActions.h"
#include "symbol.h"
#include "lable.h"
#include "convCode.h"
#include "texTo.h"
#include "cmdLine.h"
#include "preAct.h"
#include "utils.h"
#include <unistd.h>
#define SymbolMax 30

/*Pointer to lists for all data base*/
extern listP hCmdLine;
extern PSmbl hSmbl;
extern PCode hCode;
extern pLblList hExtSmbl;

int filesMaker(const char *fName)
{
	int flagEnt=0,flagExt=0;
	char *fnameOB = NULL,*fnameENT = NULL,*fnameEXT = NULL,*textToPrint = NULL;
	FILE *fp1,*fp2;
	PCode ptCode;
	pLblList ptEAE;	
	if(emptyCode(hCode))
	{		
		fnameOB = concatConst(fName,".ob\0");		
		if(!fnameOB || !(fp1 = fopen(fnameOB,"w")))
			return -1;
		fprintf(fp1,"m\tf\n");
		ptCode = hCode;
		while(ptCode)
		{
			textToPrint = getCode(&ptCode);			
			if(!textToPrint)
			{
				fclose(fp1);
				unlink(fnameOB);
				return -1;
			}
			fprintf(fp1,"%s\n",textToPrint);
		}
		fclose(fp1);
	}
	if(!emptyLbl(hExtSmbl))
	{
		ptEAE = hExtSmbl;
		while(ptEAE)
		{
			flagEnt = (flagEnt || !(ptEAE->lbl));
			flagExt = (flagExt || (ptEAE->lbl));
			ptEAE = ptEAE->next;
		}
		if (flagExt)
		{
			fnameEXT = concatConst(fName,".ext\0");
			if(!fnameEXT || !(fp1 = fopen(fnameEXT,"w")))
			{
				unlink(fnameOB);
				return -1;
			}
		}
		if(flagEnt)
		{
			fnameENT = concatConst(fName,".ent\0");
			if(!fnameENT || !(fp2 = fopen(fnameENT,"w")))
			{
				unlink(fnameOB);
				if(fnameEXT) {unlink(fnameEXT);}
				return -1;
			}
		}

		ptEAE = hExtSmbl;
		while(ptEAE)
		{
			if(ptEAE->lbl)
			{
				fprintf(fp1,"%s\t%s\n",ptEAE->name,ptEAE->address);
			}else
			{
				fprintf(fp2,"%s\t%s\n",ptEAE->name,ptEAE->address);
			}
			ptEAE = ptEAE->next;
		}
		if (flagExt)
			fclose(fp1);
		if(flagEnt)
			fclose(fp2);
	}

	return 1;
}

int InfoCode(int IC)
{
	PCode last = hCode,temp;
	listP head = hCmdLine;
	char *bin;
	if(last)
		while(last->next)
			last = last->next;
	else
	{
		if(head)
		{
			if((temp = (PCode)malloc(sizeof(codeNode))) && (bin = decToBin(head->list)))
			{
				temp->address = IC+head->DC;
				temp->bin = bin;
				hCode = temp;
				last = temp;
			}
			else{
				return -2;
			}
		}
	}

	while(head)
	{
		if((temp = (PCode)malloc(sizeof(codeNode))) && (bin = decToBin(head->list)))
		{
			temp->address = IC+head->DC;
			temp->bin = bin;
			last->next = temp;
			last = last->next;
		}
		else{
			return -2;
		}
		head = head->next;
	}
	return last->address;
}
char *addToDataBace(unsigned int arr[],int n,int *IC)
{
	int i;
	char *bin;
	for(i=0;i<n;i++)
	{
		bin = decToBin(arr[i]);
		if(bin[0] == '%' || addCode(&hCode,*IC,bin) == -2)
			return "`Dynamic allocatio error.\0";
		(*IC)+=1;
	}
	return NULL;
}
char *cmdToCode(char *cmd, int indxAct, int *IC, int source)
{
	unsigned int nextLine[5] = {0,0,0,0,0};/*there max:5 lines that we will need to add.*/
	int numberOfLine = 0;/*to know how many lines to convert to actual code.*/
	int result;
	int Addressing1,Addressing2,end,i;
	static char SyName[SymbolMax];
	PSmbl temp;
	/*frist line*/
	numberOfLine++;
	nextLine[0]|= (indxAct<<6);
	source+=3;
	if(indxAct>=14)
	{
		if(indxAct == 15)
			source+=2;			
		if(!textEnd(source,cmd))
			return "`Syntax error, unexpected text after action name.\0";
		else
			return addToDataBace(nextLine,numberOfLine,IC);
	}
	/*second line*/
	if(!textEnd(source,cmd))
		return "`Syntax error, expected operate after action name.\0";
	source = jumpSpace(cmd,source);
	Addressing1 = getMetdAdrs(cmd,source);	
	switch (Addressing1)
	{
		case 0:/*meens cmd[source] = "#..."*/
		if(indxAct<=3 || indxAct == 12){
			source++;
			end = 0;
			end = numLocation(cmd,source);
			if(end>0)/*there is a valid number between source to end*/
			{
				result = txtToInt(cmd,source,end-1);
				if(result>128 || result<-128)/*we have only 8 bit + 2 for type of coadind*/
					return "`Syntax error, number can be between 128 to -128 in this action.\0";	
				nextLine[numberOfLine]|= ((result<<2)&(-4));
				/*int nextLine[0] in adresing we live it '0'.*/
				numberOfLine++;
				source = end;
			}
			else
				return "`Syntax error, expected a number after '#' in first operate.\0";
		}
		else
			return "`Syntax error, Addressing number: 0, can't be in first operate, at this action.\0";
		break;
		case 1:
		end = 0;
		end = strEnd(cmd, source);
		if(end - source >= SymbolMax)
			return "`Syntax error, too much long text afte action name. Symbol name can't be more then 30 chars.\0";
		for(i=0;i<end - source;i++)
			SyName[i] = cmd[source+i];
		SyName[i] = '\0';
		if((temp = isSymblExist(hSmbl,SyName)))
		{
			nextLine[numberOfLine]|= (temp->addresSymbol)<<2;
			if(temp->type != 2)/*meens ENTERNAL sdymbol*/
				nextLine[numberOfLine]|= 2;/*10*/
			else				/*meens EXTERNAL sdymbol*/
			{
				nextLine[numberOfLine]|= 1;/*01*/
				if( addLbl(&hExtSmbl, temp->name , (*IC) + numberOfLine, 1) == -2)
					return "`Dynamic allocatio error.\0";
			}
			if(indxAct<=3 || indxAct == 6)/*check if it is target or source*/
				nextLine[0]|= 1<<4;
			else
				nextLine[0]|= 1<<2;
			/*int nextLine[0] in adresing we live it '0'.*/
			numberOfLine++;
			source = end;
		}
		else
			return "`Syntax error, Symbol tyiped in fisrt action dosn't exist.\0";
		break;
		case 2:/*meens THER IS a '.' */
		end = 0;
		while(cmd[source+end] != '.')
			end++;
		if(end >= SymbolMax)
			return "`Syntax error, too much long text afte action name. Symbol name can't be more then 30 chars.\0";
		for(i=0;i<end;i++)
			SyName[i] = cmd[source+i];
		SyName[i] = '\0';		
		if((temp = isSymblExist(hSmbl,SyName)))
		{
			if(temp->type == 1 || temp->type == 2)
			{
				source += end+1;
				nextLine[numberOfLine]|= (temp->addresSymbol)<<2;
				numberOfLine++;
				if(cmd[source] == '1' || cmd[source] == '2')
					nextLine[numberOfLine]|= (cmd[source] - '0')<<2;
				else
					return "`Syntax error, expected 1 or 2 after: '.' in struct name in first operate.\0";
				if(temp->type != 2){/*meens ENTERNAL sdymbol*/				
					nextLine[numberOfLine-1]|= 2;/*10*/
					nextLine[numberOfLine]|= 0;/*00*/
				}
				else{				/*meens EXTERNAL sdymbol*/
					nextLine[numberOfLine-1]|= 1;/*01*/
					nextLine[numberOfLine]|= 0;/*00*/
					if( addLbl(&hExtSmbl, temp->name , (*IC) + numberOfLine, 1) == -2)
						return "`Dynamic allocatio error.\0";
				}

				if(indxAct<=3 || indxAct == 6)/*check if it is target or source*/
					nextLine[0]|= 2<<4;
				else
					nextLine[0]|= 2<<2;				
				numberOfLine++;
				source++;
			}
			else
				return "`Syntax error, expected symbol of struct.\0";
		}
		else
			return "`Syntax error, Symbol (struct) tyiped in fisrt action dosn't exist.\0";
		break;
		case 3:/*meens cmd[source] = "r*..." */
		if(indxAct != 6)
		{
			source++;
			if(indxAct<=3)/*check if it is target or source*/
			{
				nextLine[0]|= 3<<4;
				nextLine[numberOfLine]|= (cmd[source] - '0')<<6;
			}
			else
			{
				nextLine[0]|= 3<<2;
				nextLine[numberOfLine]|= (cmd[source] - '0')<<2;
			}
			numberOfLine++;
			source++;
		}
		else
			return "`Syntax error, Addressing number: 0, can't be in first addressing at this action.\0";
		break;
	}
	/*third line line*/
	if(indxAct<=3 || indxAct == 6)
	{
		source = jumpComma(cmd,source);
		if(source<0)
			return "`Syntax error, expected a break ',' and another operate in this action.\0";
		source = jumpSpace(cmd,source);
		Addressing2 = getMetdAdrs(cmd,source);
		switch(Addressing2)
		{
			case 0:
			if(indxAct == 1)
			{
				source++;
				end = 0;
				end = numLocation(cmd,source);
				if(end>0)/*there is a valid number between source to end*/
				{
					result = txtToInt(cmd,source,end-1);
					if(result>128 || result<-128)/*we have only 8 bit + 2 for type of coadind*/
						return "`Syntax error, number can be between 128 to -128 in this action.\0";	
					nextLine[numberOfLine]|= ((result<<2)&(-4));
					/*int nextLine[0] in adresing we live it '0'.*/
					numberOfLine++;
					source = end;
				}
				else
					return "`Syntax error, expected a number after '#' in second operate.\0";
			}
			else
				return "`Syntax error, Addressing number: 0, can't be in second addressing at this action.\0";
			break;
			case 1:
			end = 0;
			end = strEnd(cmd, source);
			if(end - source >= SymbolMax)
				return "`Syntax error, too much long text afte action name. Symbol name can't be more then 30 chars.\0";
			for(i=0;i<end - source;i++)
				SyName[i] = cmd[source+i];
			SyName[i] = '\0';
			if((temp = isSymblExist(hSmbl,SyName)))
			{
				nextLine[numberOfLine]|= (temp->addresSymbol)<<2;
				if(temp->type != 2)/*meens ENTERNAL sdymbol*/
					nextLine[numberOfLine]|= 2;/*10*/
				else
				{/*meens EXTERNAL sdymbol*/
					nextLine[numberOfLine]|= 1;/*01*/
					if( addLbl(&hExtSmbl, temp->name , (*IC) + numberOfLine, 1) == -2)
						return "`Dynamic allocatio error.\0";
				}				
				nextLine[0]|= 1<<2;				
				numberOfLine++;
				source = end;
			}
			else
				return "`Syntax error, Symbol tyiped in second operate dosn't exist.\0";
			break;
			case 2:/*meens THER IS a '.' */
			end = 0;
			while(cmd[source+end]!= '.')
				end++;		
			if(end >= SymbolMax)
				return "`Syntax error, too much long text afte break ','. Symbol name can't be more then 30 chars.\0";
			for(i=0;i<end;i++)
				SyName[i] = cmd[source+i];
			SyName[i] = '\0';		
			if((temp = isSymblExist(hSmbl,SyName)))
			{
				if(temp->type == 1 || temp->type == 2)
				{
					source += end+1;
					nextLine[numberOfLine]|= (temp->addresSymbol)<<2;
					numberOfLine++;
					if(cmd[source] == '1' || cmd[source] == '2')
						nextLine[numberOfLine]|= (cmd[source] - '0')<<2;
					else
						return "`Syntax error, expected 1 or 2 after: '.' in second operate.\0";
					if(temp->type != 2){/*meens ENTERNAL sdymbol*/				
						nextLine[numberOfLine-1]|= 2;/*10*/
						nextLine[numberOfLine]|= 0;/*00*/
					}
					else{				/*meens EXTERNAL sdymbol*/
						nextLine[numberOfLine-1]|= 1;/*01*/
						nextLine[numberOfLine]|= 0;/*00*/
						if( addLbl(&hExtSmbl, temp->name , (*IC) + numberOfLine, 1) == -2)
							return "`Dynamic allocatio error.\0";
					}					
					nextLine[0]|= 2<<2;				
					numberOfLine++;
					source++;
				}
				else
					return "`Syntax error, expected symbol of struct.\0";
			}
			else
				return "`Syntax error, Symbol tyiped in fisrt action dosn't exist.\0";			
			break;
			case 3:/*meens cmd[source] = "r*..." */
			source++;
			nextLine[0]|= 3<<2;
			if(Addressing1 == 3)/*check if needed enother word*/
			{
				nextLine[numberOfLine-1]|= (cmd[source] - '0')<<2;
			}
			else
			{
				nextLine[numberOfLine]|= (cmd[source] - '0')<<2;
				numberOfLine++;
			}
			source++;
			break;
		}
	}
	else
	{
		if(textEnd(source,cmd))
			return "`Syntax error, unexpected text, after operate.\0";
	}
	if(textEnd(source,cmd))
		return "`Syntax error, unexpected text after end of command.\0";
	return addToDataBace(nextLine,numberOfLine,IC);
}

char *toExt(char *cmd, int source, int end)
{
	static char name[SymbolMax];
	PSmbl temp = hSmbl;
	int Nlength = end - source +1,i,result;
	for(i=0;i<Nlength;i++)
	{
		name[i] = cmd[source+i];
	}
	name[i] = '\0';	
	while(temp)
	{		
		if(strcmp(temp->name,name) == 0)
		{			
			if(temp->type == 2)
				return "`Syntax error, entery Symbol can't be external one.\0";
			result = addLbl(&hExtSmbl, temp->name, temp->addresSymbol, 0);
			if(result == -2)
				return "`Syntax error, Error in dynamic alocation.\0";
			else
				return NULL;
		}
		temp = temp->next;
	}
	return "`Syntax error, Symbol dosn't exist in hole file.\0";
}

void endProgram()
{
	deleteList(&hCmdLine);
	deleteAll(&hSmbl);
	deleteCode(&hCode);
	deleteLbl(&hExtSmbl);
}
