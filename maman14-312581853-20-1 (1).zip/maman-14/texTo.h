#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#ifndef mask
#define mask 1
#endif

int binToDec(char *bin);                        /* Receives an array of chars holding a number in its binary form, and returns the number in decimal*/
char * decToBin(int num);                       /* Receives a number and returns an array holding the number in binary form */
char *binToAsmMMN(char *bin);                        /* Receives a char array holding a number in binary, and returns an array holding the number in the special 32 base */
char * decToAsmMMN(int num);                     /* Receives a number, and returns an array holding the number in the special 32 base */
char* concatConst(const char *str1, const char *str2);       /* input: two strings.  Output: one string that is the combination of both strings*/
int txtToInt(char *text, int source, int end);       /* Input: Receives a string and integer 'source', and integer 'end'.  Output: A number that is a substring of this string from 'source' to 'end'*/

