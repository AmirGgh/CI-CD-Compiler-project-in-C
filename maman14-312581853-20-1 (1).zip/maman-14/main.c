#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "textActions.h"
#include "symbol.h"
#include "lable.h"
#include "convCode.h"
#include "macro.h"
#include "texTo.h"
#include "cmdLine.h"
#include "preAct.h"
#include "utils.h"
#define maxSmbl 40
#define ErrJmp \
flgErr = ERR;\
free(cmd);\
continue;
/*ErrJmp => If there is some error the macro free memory*/
/*every where there is Discounts: (1), it mean char[81] with 0 in the end of command */
enum Status {OK,ERR};
/*Pointer to lists for all lists (data base)*/
listP hCmdLine = NULL;
PSmbl hSmbl = NULL;
PCode hCode = NULL;
pLblList hExtSmbl = NULL;
short flgErr;
char syName[lineSize];

void FirstPass(FILE *);
void SecondPass(FILE *);

int main(int argc, char const *argv[])
{	
	int i;
	char *fileName = NULL;	
	FILE * f;
	if(argc <= 1)
	{
		printf("Pleas type file name after './assembler  '.\n");
		exit(0);
	}
	for	(i=1; i<argc; i++)
	{	
		if(!preAsm(argv[i]))
		{
			printf("  ***  The file %s.as couldn't be deploy becuse there are an unvalid macro name  *** \n",fileName);
		}		
		fileName =NULL;
		fileName = concatConst(argv[i],".am\0");
		
		if(fileName)
		{
			printf("  *** File - %s ***  \n",fileName);
			f = fopen(fileName, "r");
			if (f)
			{
				FirstPass(f);
				if(flgErr == ERR)
				{					
					printf("  ***  The file %s couldn't be created becuse there are error to fix init.  *** \n",fileName);
					fclose(f);
					free(fileName);
					endProgram();
					continue;
				}
				rewind(f);
				SecondPass(f);
				if(flgErr == ERR)
				{					
					printf("  ***  The file %s couldn't be created becuse there are an error.  *** \n",fileName);
					fclose(f);
					free(fileName);
					endProgram();
					continue;
				}
				if(filesMaker(argv[i]) != 1)
				{
					printf("# Error: could not creat output files to: %s\n",fileName );
				}
				else
				{
					printf("  *** all output files for %s created Successfully  ***  \n",fileName);
				}
			   	fclose(f);
			}
			else
			{
				printf("Error: The file %s.as dose not exists.\n", argv[i] );
			}
			free(fileName);
			endProgram();			
		}
		else
		{
			printf("# Error: Dynamic alocatiERR error - couldn't creat f: %s\n", argv[i]);
		}
	}
	return 1;
}

void FirstPass(FILE *f)
{
	short flagSymbol = OK;
	int index, end, intResult, intResultSec, Sy_start, Sy_length, IC = 100, DC = 0, L = 0, lineNum = 0;
	char *TEXTresult = NULL, *cmd = NULL;
	flgErr = OK;	
	while((cmd = getCmd(f)))
	{
		index = 0;
		L = 0;
		flagSymbol = OK;
		lineNum++;
		if(!textEnd(index, cmd) || cmd[jumpSpace(cmd,0)] == ';')
			continue;		
		if(cmd[index] == '`')
		{
			printf("# Error in line - %d:\n %s\n",lineNum,(cmd+index+1) );
			flgErr = ERR;			
			continue;
		}		
		index = jumpSpace(cmd,index);
		end = symbolPlace(cmd,index);
		if(end>0)
		{
			flagSymbol = ERR;
			Sy_start = index;
			Sy_length = end - index;
			if(Sy_length>=maxSmbl)
			{
				printf("# Error in line - %d, index - %d: \n Syntax error, Symbol name can't be longer than: %d.\n",lineNum,index,maxSmbl);
				ErrJmp	
			}
			index = jumpSpace(cmd,end+1);			
			if(!textEnd(index, cmd))
			{
				printf("# Error in line - %d, index - %d: \n Syntax error, expected a method name or directive after symbol.\n",lineNum,index);
				ErrJmp
			}
		}
		if(cmd[index] == '.')
		{
			intResult = directivePlace(cmd,index);
			if(intResult<=0)
			{
				printf("# Error in line - %d, index - %d: \n Syntax error, unknow directive name.\n",lineNum,index);
				ErrJmp
			}
			if(intResult<=3)
			{
				if(flagSymbol)
				{
					flagSymbol = OK;
					strncpy(syName,(cmd+Sy_start),Sy_length);			
					syName[Sy_length] = '\0';
					if(symExist(hSmbl,syName))
					{
						printf("# Error in line - %d, index - %d: \n Symbol already exist, and have been defined befor.\n",lineNum,Sy_start);						
						ErrJmp
					}
					if(intResult == 3)
						intResultSec = setSymblNext(&hSmbl, cmd, Sy_start, Sy_length, DC, 1);/*1- for sruct.*/
					else
						intResultSec = setSymblNext(&hSmbl, cmd, Sy_start, Sy_length, DC, 0);
					if(intResultSec == -2)
					{
						printf("# Error in line - %d, index - %d: \n Dynamic alocation error, could not add Symbol.\n",lineNum,Sy_start);
						ErrJmp
					}
				}
				switch(intResult)
				{
					case 1:
					intResultSec = addList(cmd, index, &DC, &hCmdLine);
					if(intResultSec < 0 && intResultSec != -2)
					{
						printf("# Error in line - %d, index - %d: \n Syntax error, after directive name. (expected: number,number..) note: all number must be between: -512:512 .\n",lineNum,index);
						ErrJmp
					}					
					break;
					case 2:
					intResultSec = addStr(cmd, index, &DC, &hCmdLine);
					if(intResultSec < 0 && intResultSec != -2)
					{
						printf("# Error in line - %d, index - %d: Syntax error, after directive name. (expected: \"sum_text\").\n",lineNum,index);	
						ErrJmp						
					}					
					break;
					case 3:					
					intResultSec = addStruct(cmd, index, &DC, &hCmdLine);
					if(intResultSec < 0 && intResultSec != -2)
					{
						printf("# Error in line - %d, index - %d: Syntax error, after directive name. (expected: number,\"sum_text\").\n",lineNum,index);
						ErrJmp
					}					
					break;
				}
				if(intResultSec == -2)
				{
					printf("# Error in line - %d, index - %d:\n Dynamic alocation error, could not add data.\n",lineNum,index);					
					ErrJmp
				}
				if(textEnd(intResultSec, cmd))
				{
					printf("# Error in line - %d, index - %d: \n Syntax error, unexpected text after directive order.\n",lineNum,intResultSec);
					ErrJmp
				}				
			}
			else
			{
				if(flagSymbol)
				{
					flagSymbol = OK;
					printf("(!) Warning in line - %d, index - %d:\n unexpected Symbol in this type of directive.\n",lineNum,Sy_start);				
				}
				if(intResult == 5)
				{					
					index += externSize;
					if(textEnd(index, cmd)) 
					{
						index = jumpSpace(cmd,index);
						intResultSec = addNextSymbols(&hSmbl, cmd, index);
						if(intResultSec<0)
						{
							switch(intResultSec)
							{
								case -2:
								printf("# Error in line - %d, index - %d:\n Dynamic alocation error, could not add Symbol.\n",lineNum,Sy_start);
								ErrJmp
								break;
								case -3:								
								printf("# Error in line - %d, index - %d:\n Syntax error, unexpected text after adding symbols.\n",lineNum,index);
								ErrJmp
								break;
								default :
								printf("# Error in line - %d, index - %d:\n Syntax error, expected symbol name.\n",lineNum,index);
								ErrJmp
							}							
						}
					}					
					else
					{
						printf("# Error in line - %d, index - %d:\n expected symbol name afted directive: extern.\n",lineNum,Sy_start);
						ErrJmp
					}					
				}
			}
			free(cmd);
			continue;
		}
		if(flagSymbol)
		{
			flagSymbol = OK;
			strncpy(syName,(cmd+Sy_start),Sy_length);					
			syName[Sy_length] = '\0';
			if(symExist(hSmbl,syName))
			{
				printf("# Error in line - %d, index - %d:\n Syntax error, Symbol already exist, and have been defined befor.\n",lineNum,Sy_start);						
				ErrJmp
			}			
			intResultSec = setSymblNext(&hSmbl, cmd, Sy_start, Sy_length, IC, 3);/*3- for code Symbol.*/			
			if(intResultSec == -2)
			{
				printf("# Error in line - %d, index - %d:\n Dynamic alocation error, could not add Symbol.\n",lineNum,Sy_start);
				ErrJmp
			}
		}
		intResult = isCmd(cmd,index);
		if(intResult<0)
		{
			printf("# Error in line - %d, index - %d:\n Syntax error, unknow order name.\n",lineNum,index);
			ErrJmp
		}
		TEXTresult = countAct(intResult, &L, cmd, index);
		if(TEXTresult != NULL && TEXTresult[0] == '`')
		{
			printf("# Error in line - %d, index - %d:\n %s.\n",lineNum,index,(TEXTresult+1));
			ErrJmp
		}
		IC+=L;
		free(cmd);
	}
	updateSymbolTyp(hSmbl,IC);	
}


void SecondPass(FILE *f)
{	
	int index, end, intResult, intResultSec, IC = 100, lineNum = 0;
	char *TEXTresult = NULL, *cmd = NULL;
	flgErr = OK;
	while((cmd = getCmd(f)))
	{
		index = 0;		
		lineNum++;
		if(!textEnd(index,cmd) || cmd[jumpSpace(cmd,0)] == ';')
			continue;		
		if(cmd[index] == '`')
		{
			printf("# Error in line - %d:\n %s\n",lineNum,(cmd+index+1) );
			flgErr = ERR;			
			continue;
		}
		index = jumpSpace(cmd,index);
		end = symbolPlace(cmd,index);
		if(end>0)
			index = jumpSpace(cmd,end+1);
		if(cmd[index] == '.')
		{
			intResult = directivePlace(cmd,index);			
			if(intResult == 4)
			{				
				index += entrySize;
				if(textEnd(index,cmd))
				{					
					index = jumpSpace(cmd,index);
					end = strEnd(cmd,index);
					if((end-index) > maxSmbl)
					{
						printf("# Error in line - %d, index - %d:\n Syntax error, symbol name is too long. Can't pass: %d chars.\n",lineNum,index,maxSmbl);
						ErrJmp
					}
					TEXTresult = toExt(cmd,index,end-1);
					if(textEnd(end, cmd))
					{
						printf("# Error in line - %d, index - %d:\n Syntax error, unexpected text after symbol name.\n",lineNum,jumpSpace(cmd,end));
						ErrJmp
					}
					if(TEXTresult)
					{
						printf("# Error in line - %d, index - %d:\n %s.\n",lineNum,index,TEXTresult);
						ErrJmp
					}
				}
				else
				{
					printf("# Error in line - %d, index - %d:\n Syntax error, expected symbol name afted directive: entry.\n",lineNum,index);
					ErrJmp
				}
			}
			free(cmd);
			continue;
		}
		intResult = isCmd(cmd,index);
		if(intResult<0)
		{			
			ErrJmp
		}
		TEXTresult = cmdToCode(cmd, intResult, &IC, index);
		if(TEXTresult != NULL && TEXTresult[0] == '`')
		{
			printf("# Error in line - %d, index - %d:\n %s.\n",lineNum,index,(TEXTresult+1));
			ErrJmp
		}		
		free(cmd);
	}
	intResultSec =  InfoCode(IC);
	if(intResultSec == -2)
	{
		printf("# Error:\n Dynamic alocation error, couldn't add new data to code.\n");
		flgErr = ERR;		
	}
}
